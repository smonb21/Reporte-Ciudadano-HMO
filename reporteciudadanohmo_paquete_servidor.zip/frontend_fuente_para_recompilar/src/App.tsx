import { useState, useEffect } from 'react';
import { Camera, ShieldAlert, ClipboardList } from 'lucide-react';
import type { CiudadanoReport } from './types';
import { ReportTab } from './components/ReportTab';
import { AlertsTab } from './components/AlertsTab';
import { MyReportsTab } from './components/MyReportsTab';
import { PrintableOficio } from './components/PrintableOficio';
import { stopSpeaking } from './utils/speech';

type ActiveTab = 'reportar' | 'alertas' | 'mis-reportes';

const STORAGE_REPORTS_KEY = 'hmo_mis_reportes_v1';

function loadUserReports(): CiudadanoReport[] {
  try {
    const raw = localStorage.getItem(STORAGE_REPORTS_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('reportar');
  const [userReports, setUserReports] = useState<CiudadanoReport[]>(loadUserReports);
  const [printingReport, setPrintingReport] = useState<CiudadanoReport | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_REPORTS_KEY, JSON.stringify(userReports));
    } catch {
      // Ignora error de almacenamiento
    }
  }, [userReports]);

  const handleReportCreated = (report: CiudadanoReport) => {
    setUserReports((prev) => [report, ...prev]);
  };

  const handleUpdateReport = (id: string, updates: Partial<CiudadanoReport>) => {
    setUserReports((prev) =>
      prev.map((item) => (item.id === id ? { ...item, ...updates } : item)),
    );
  };

  const handleDeleteReport = (id: string) => {
    setUserReports((prev) => prev.filter((item) => item.id !== id));
  };

  const handleSwitchTab = (tab: ActiveTab) => {
    stopSpeaking();
    setActiveTab(tab);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <>
      <PrintableOficio report={printingReport} onClose={() => setPrintingReport(null)} />
      <div className="min-h-screen bg-[#FAF8F5] text-[#111827] pb-28 print:hidden">
        <header className="sticky top-0 z-30 border-b-2 border-[#D6D3CD] bg-white/95 backdrop-blur-sm">
          <div className="mx-auto flex h-[58px] max-w-2xl items-center justify-between px-4">
            <h1 className="truncate text-[20px] font-extrabold tracking-tight text-[#0F2C59]">
              Reporte Ciudadano HMO
            </h1>
          </div>
        </header>

        <main className="mx-auto max-w-2xl px-4 py-5">
          {activeTab === 'reportar' && (
            <ReportTab
              onReportCreated={handleReportCreated}
              onGoToMyReports={() => handleSwitchTab('mis-reportes')}
              onPrintReport={setPrintingReport}
            />
          )}

          {activeTab === 'alertas' && <AlertsTab />}

          {activeTab === 'mis-reportes' && (
            <MyReportsTab
              reports={userReports}
              onUpdateReport={handleUpdateReport}
              onDeleteReport={handleDeleteReport}
              onGoToCreate={() => handleSwitchTab('reportar')}
              onPrintReport={setPrintingReport}
            />
          )}
        </main>

        <nav
          aria-label="Navegación principal"
          className="fixed bottom-0 left-0 right-0 z-40 border-t-2 border-[#111827] bg-white pb-safe shadow-lg"
        >
          <div className="mx-auto grid h-[74px] max-w-2xl grid-cols-3 gap-1.5 px-2 py-1.5">
            <button
              type="button"
              onClick={() => handleSwitchTab('reportar')}
              aria-current={activeTab === 'reportar' ? 'page' : undefined}
              className={`flex flex-col items-center justify-center rounded-xl px-1 transition-colors ${
                activeTab === 'reportar'
                  ? 'bg-[#0F2C59] text-white'
                  : 'bg-[#FAF8F5] text-[#111827] hover:bg-[#EFECE6]'
              }`}
            >
              <Camera className="h-6 w-6 shrink-0" aria-hidden="true" />
              <span className="mt-0.5 whitespace-nowrap text-[14px] font-extrabold leading-none tracking-tight sm:text-[16px]">
                Hacer Reporte
              </span>
            </button>

            <button
              type="button"
              onClick={() => handleSwitchTab('alertas')}
              aria-current={activeTab === 'alertas' ? 'page' : undefined}
              className={`flex flex-col items-center justify-center rounded-xl px-1 transition-colors ${
                activeTab === 'alertas'
                  ? 'bg-[#C2410C] text-white'
                  : 'bg-[#FAF8F5] text-[#111827] hover:bg-[#EFECE6]'
              }`}
            >
              <ShieldAlert className="h-6 w-6 shrink-0" aria-hidden="true" />
              <span className="mt-0.5 whitespace-nowrap text-[14px] font-extrabold leading-none tracking-tight sm:text-[16px]">
                Alertas Vecinales
              </span>
            </button>

            <button
              type="button"
              onClick={() => handleSwitchTab('mis-reportes')}
              aria-current={activeTab === 'mis-reportes' ? 'page' : undefined}
              className={`flex flex-col items-center justify-center rounded-xl px-1 transition-colors ${
                activeTab === 'mis-reportes'
                  ? 'bg-[#0F2C59] text-white'
                  : 'bg-[#FAF8F5] text-[#111827] hover:bg-[#EFECE6]'
              }`}
            >
              <ClipboardList className="h-6 w-6 shrink-0" aria-hidden="true" />
              <span className="mt-0.5 whitespace-nowrap text-[14px] font-extrabold leading-none tracking-tight sm:text-[16px]">
                Mis Reportes
              </span>
            </button>
          </div>
        </nav>
      </div>
    </>
  );
}
