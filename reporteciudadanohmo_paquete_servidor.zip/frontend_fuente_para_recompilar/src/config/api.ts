export const API_ENDPOINTS = {
  analizar: '/reporteciudadanohmo/api/analizar.php',
  reportes: '/reporteciudadanohmo/api/reportes.php',
  alertas: '/reporteciudadanohmo/api/alertas.php',
} as const;

export const APP_TOKEN = (import.meta.env.VITE_APP_TOKEN || '').trim();

export function buildApiHeaders(): Record<string, string> {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };
  if (APP_TOKEN !== '') {
    headers['X-App-Token'] = APP_TOKEN;
  }
  return headers;
}

export function getFriendlyHttpMessage(status: number): string {
  switch (status) {
    case 401:
      return 'No pudimos validar tu sesión en la aplicación. Por favor recarga la página e intenta de nuevo.';
    case 422:
      return 'Falta información o la foto/audio excede el tamaño permitido. Revisa los datos e intenta otra vez.';
    case 429:
      return 'Se enviaron muchas solicitudes seguidas. Espera un minuto antes de volver a intentar.';
    case 500:
    case 502:
    case 503:
      return 'El servidor tuvo un problema temporal. Intenta de nuevo en unos segundos.';
    default:
      return 'No se pudo completar la operación. Verifica tu conexión a internet.';
  }
}
