export type DependenciaHMO =
  | 'Obras Públicas / CIDUE'
  | 'Alumbrado Público'
  | 'Agua de Hermosillo'
  | 'Servicios Públicos'
  | 'Protección Civil';

export type NivelRiesgo = 'Alto' | 'Medio' | 'Bajo';

export interface ReporteFormalDetalle {
  asunto: string;
  descripcion: string;
  ubicacion: string;
  evidencia: string;
  afectacion_accesibilidad: string;
  prioridad_sugerida: 'Urgente' | 'Media' | 'Programada';
}

export interface AnalisisResponseData {
  es_problema_urbano: boolean;
  tipo_obstaculo: string;
  riesgo: NivelRiesgo;
  motivo_riesgo: string;
  dependencia: DependenciaHMO;
  confianza_dependencia: 'Alta' | 'Media' | 'Baja';
  reporte_formal: ReporteFormalDetalle;
  resumen_corto: string;
  mensaje_usuario: string;
}

export interface CiudadanoReport {
  id: string;
  folio: string;
  fecha: string;
  colonia: string;
  ubicacion_texto: string;
  lat: number;
  lng: number;
  fuera_de_zona?: boolean;
  fotoDataUrl?: string;
  detalles_usuario?: string;
  dependencia: DependenciaHMO;
  nivel_riesgo: NivelRiesgo;
  accesibilidad_espacio: string;
  motivo_riesgo: string;
  confianza_dependencia?: 'Alta' | 'Media' | 'Baja';
  resumen_problema: string;
  reporte_formal: ReporteFormalDetalle;
  oficio_formal: string;
  mensaje_ciudadano: string;
  alerta_preventiva: string;
  estado: string;
  esPropio: boolean;
}

export interface AlertaComunitariaItem {
  titulo: string;
  recomendacion: string;
  nivel: NivelRiesgo;
  referencia: string;
}

export interface AlertsSummary {
  resumen_general: string;
  alertas: AlertaComunitariaItem[];
}

export interface ReportePublicoItem {
  folio: string;
  tipo_obstaculo: string;
  riesgo: NivelRiesgo;
  motivo_riesgo: string;
  dependencia: DependenciaHMO;
  resumen_corto: string;
  colonia: string;
  ubicacion_texto: string;
  lat: number;
  lng: number;
  es_demo: number;
  creado_en: string;
  distancia_km: number;
}
