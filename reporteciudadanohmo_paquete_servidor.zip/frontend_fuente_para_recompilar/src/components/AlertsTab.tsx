import { useState, useEffect } from 'react';
import {
  ShieldAlert,
  AlertTriangle,
  MapPin,
  Volume2,
  VolumeX,
  ExternalLink,
  Loader2,
  RefreshCw,
} from 'lucide-react';
import type { AlertsSummary, ReportePublicoItem } from '../types';
import { API_ENDPOINTS, buildApiHeaders, getFriendlyHttpMessage } from '../config/api';
import { speakSpanish, stopSpeaking } from '../utils/speech';

export function AlertsTab() {
  const [coords, setCoords] = useState<{ lat: number; lng: number }>({
    lat: 29.0729,
    lng: -110.9559,
  });
  const [reportes, setReportes] = useState<ReportePublicoItem[]>([]);
  const [summary, setSummary] = useState<AlertsSummary | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState('');
  const [isSpeakingTips, setIsSpeakingTips] = useState(false);

  const loadZoneData = async (lat: number, lng: number) => {
    setIsLoading(true);
    setErrorMsg('');
    try {
      const headers = buildApiHeaders();
      const [repRes, alertRes] = await Promise.all([
        fetch(`${API_ENDPOINTS.reportes}?lat=${lat}&lng=${lng}&radio_km=5&limite=30`, { headers }),
        fetch(`${API_ENDPOINTS.alertas}?lat=${lat}&lng=${lng}`, { headers }),
      ]);

      if (!repRes.ok) {
        setErrorMsg(getFriendlyHttpMessage(repRes.status));
        return;
      }
      if (!alertRes.ok) {
        setErrorMsg(getFriendlyHttpMessage(alertRes.status));
        return;
      }

      const repJson = await repRes.json();
      const alertJson = await alertRes.json();

      setReportes(Array.isArray(repJson.reportes) ? repJson.reportes : []);
      setSummary({
        resumen_general: alertJson.resumen_general || '',
        alertas: Array.isArray(alertJson.alertas) ? alertJson.alertas : [],
      });
    } catch {
      setErrorMsg('Sin conexión para cargar las alertas vecinales. Intenta de nuevo.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadZoneData(coords.lat, coords.lng);
    return () => {
      stopSpeaking();
    };
  }, []);

  const handleDetectAndReload = () => {
    if (typeof navigator !== 'undefined' && navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const next = { lat: pos.coords.latitude, lng: pos.coords.longitude };
          setCoords(next);
          loadZoneData(next.lat, next.lng);
        },
        () => loadZoneData(coords.lat, coords.lng),
        { enableHighAccuracy: true, timeout: 10000 },
      );
    } else {
      loadZoneData(coords.lat, coords.lng);
    }
  };

  const handleSpeakSummary = () => {
    if (!summary) return;
    if (isSpeakingTips) {
      stopSpeaking();
      setIsSpeakingTips(false);
      return;
    }

    const alertasTexto = summary.alertas
      .map((a) => `${a.titulo} en ${a.referencia}. ${a.recomendacion}`)
      .join('. ');
    const fullText = `Consejos de Movilidad Segura. ${summary.resumen_general}. ${alertasTexto}`;

    speakSpanish(fullText, {
      onStart: () => setIsSpeakingTips(true),
      onEnd: () => setIsSpeakingTips(false),
    });
  };

  return (
    <section aria-labelledby="alerts-heading" className="space-y-6">
      <div className="rounded-2xl border-2 border-[#C2410C] bg-[#FFF7ED] p-5 shadow-sm space-y-4">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-start gap-3">
            <ShieldAlert className="mt-1 h-8 w-8 shrink-0 text-[#C2410C]" aria-hidden="true" />
            <h2 id="alerts-heading" className="text-[22px] font-extrabold leading-snug text-[#111827]">
              Consejos de Movilidad Segura en tu Zona
            </h2>
          </div>

          <button
            type="button"
            onClick={handleDetectAndReload}
            aria-label="Actualizar alertas cercanas"
            className="flex min-h-[44px] min-w-[44px] shrink-0 items-center justify-center rounded-xl border-2 border-[#C2410C] bg-white text-[#C2410C]"
          >
            <RefreshCw className={`h-5 w-5 ${isLoading ? 'animate-spin' : ''}`} aria-hidden="true" />
          </button>
        </div>

        {isLoading ? (
          <div className="flex items-center gap-3 text-[18px] font-bold text-[#374151]">
            <Loader2 className="h-6 w-6 animate-spin" aria-hidden="true" />
            <span>Consultando reportes cercanos…</span>
          </div>
        ) : errorMsg ? (
          <p role="alert" className="text-[18px] font-bold text-[#9A3412]">
            {errorMsg}
          </p>
        ) : summary ? (
          <div className="space-y-4">
            <p className="text-[18px] font-bold leading-relaxed text-[#111827]">
              {summary.resumen_general}
            </p>

            {summary.alertas.length > 0 && (
              <ul className="space-y-3 text-[18px] leading-relaxed text-[#111827]">
                {summary.alertas.map((alerta, idx) => (
                  <li key={idx} className="rounded-xl border border-[#FDBA74] bg-white p-3.5">
                    <p className="font-extrabold text-[#111827]">
                      Nivel {alerta.nivel} · {alerta.titulo}
                    </p>
                    <p className="text-[#374151]">{alerta.referencia}</p>
                    <p className="mt-1">{alerta.recomendacion}</p>
                  </li>
                ))}
              </ul>
            )}

            <button
              type="button"
              onClick={handleSpeakSummary}
              className="flex min-h-[64px] w-full items-center justify-center gap-3 rounded-xl bg-[#0F2C59] px-5 py-3 text-[22px] font-bold text-white hover:bg-[#0A1F40]"
            >
              {isSpeakingTips ? (
                <>
                  <VolumeX className="h-7 w-7 shrink-0" aria-hidden="true" />
                  <span>Detener consejos</span>
                </>
              ) : (
                <>
                  <Volume2 className="h-7 w-7 shrink-0" aria-hidden="true" />
                  <span>Escuchar consejos</span>
                </>
              )}
            </button>
          </div>
        ) : null}
      </div>

      <div className="space-y-4">
        <h3 className="text-[22px] font-extrabold text-[#111827]">
          Reportes Cercanos ({reportes.length})
        </h3>

        {reportes.map((rep) => (
          <article
            key={rep.folio}
            className="rounded-2xl border-2 border-[#D6D3CD] bg-white p-5 shadow-sm space-y-3"
          >
            <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-[18px] font-bold">
              <span
                className={`inline-flex items-center gap-1.5 ${
                  rep.riesgo === 'Alto'
                    ? 'text-[#B91C1C]'
                    : rep.riesgo === 'Medio'
                      ? 'text-[#C2410C]'
                      : 'text-[#166534]'
                }`}
              >
                <AlertTriangle className="h-5 w-5 shrink-0" aria-hidden="true" />
                <span>Riesgo {rep.riesgo}</span>
              </span>
              <span aria-hidden="true" className="text-[#6B7280]">·</span>
              <span className="text-[#374151]">{rep.dependencia}</span>
              <span aria-hidden="true" className="text-[#6B7280]">·</span>
              <span className="tabular-nums text-[#374151]">{rep.distancia_km} km</span>
            </div>

            <h4 className="text-[22px] font-extrabold leading-snug text-[#111827]">
              {rep.resumen_corto}
            </h4>

            <p className="flex items-start gap-2 text-[18px] font-bold text-[#374151]">
              <MapPin className="mt-1 h-5 w-5 shrink-0 text-[#0F2C59]" aria-hidden="true" />
              <span>{rep.ubicacion_texto || rep.colonia}</span>
            </p>

            <p className="text-[18px] leading-relaxed text-[#111827]">{rep.motivo_riesgo}</p>

            <a
              href={`https://www.google.com/maps?q=${rep.lat},${rep.lng}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex min-h-[60px] w-full items-center justify-center gap-2.5 rounded-xl border-2 border-[#0F2C59] bg-[#EEF2F8] px-4 py-3 text-[22px] font-bold text-[#0F2C59] hover:bg-[#DCE6F5]"
            >
              <ExternalLink className="h-6 w-6 shrink-0" aria-hidden="true" />
              <span>Ver ubicación en Google Maps</span>
            </a>
          </article>
        ))}
      </div>
    </section>
  );
}
