import { useState, useRef, useEffect } from 'react';
import {
  Camera,
  Mic,
  Square,
  Keyboard,
  MapPin,
  Send,
  Volume2,
  VolumeX,
  CheckCircle2,
  AlertTriangle,
  RotateCcw,
  ImagePlus,
  Loader2,
  ClipboardList,
  Download,
  Printer,
  Check,
  RefreshCw,
  ExternalLink,
  Share2,
} from 'lucide-react';
import type { AnalisisResponseData, CiudadanoReport } from '../types';
import { API_ENDPOINTS, buildApiHeaders, getFriendlyHttpMessage } from '../config/api';
import { compressImageFile, blobToBase64 } from '../utils/imageCompress';
import { speakSpanish, stopSpeaking } from '../utils/speech';
import { downloadOficioTxt } from '../utils/oficioExport';

interface ReportTabProps {
  onReportCreated: (report: CiudadanoReport) => void;
  onGoToMyReports: () => void;
  onPrintReport: (report: CiudadanoReport) => void;
}

interface SpeechRecognitionInstance {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  onresult: ((event: { results: ArrayLike<ArrayLike<{ transcript: string }>> }) => void) | null;
  onerror: (() => void) | null;
  onend: (() => void) | null;
  start: () => void;
  stop: () => void;
}

const HERMOSILLO_FALLBACK_COORDS = {
  lat: 29.0729,
  lng: -110.9559,
};

function formatReporteFormalText(analisis: AnalisisResponseData, folio: string): string {
  const rf = analisis.reporte_formal;
  return [
    'REPORTE CIUDADANO HMO (HERMOSILLO, SONORA)',
    `Folio: ${folio}`,
    `Dependencia probable: ${analisis.dependencia}`,
    `Prioridad sugerida: ${rf.prioridad_sugerida}`,
    `Asunto: ${rf.asunto}`,
    '',
    `Ubicación: ${rf.ubicacion}`,
    `Descripción: ${rf.descripcion}`,
    `Evidencia: ${rf.evidencia}`,
    `Afectación a accesibilidad: ${rf.afectacion_accesibilidad}`,
  ].join('\n');
}

export function ReportTab({
  onReportCreated,
  onGoToMyReports,
  onPrintReport,
}: ReportTabProps) {
  const cameraInputRef = useRef<HTMLInputElement>(null);
  const galleryInputRef = useRef<HTMLInputElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const speechRecRef = useRef<SpeechRecognitionInstance | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<number | null>(null);

  const [photoDataUrl, setPhotoDataUrl] = useState<string>('');
  const [photoBase64, setPhotoBase64] = useState<string>('');
  const [photoMimeType, setPhotoMimeType] = useState<string>('image/jpeg');

  const [isRecording, setIsRecording] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const [textoVoz, setTextoVoz] = useState<string>('');
  const [audioUrl, setAudioUrl] = useState<string>('');
  const [audioBase64, setAudioBase64] = useState<string>('');
  const [audioMimeType, setAudioMimeType] = useState<string>('audio/ogg');
  const [micNotice, setMicNotice] = useState<string>('');

  const [showTextBox, setShowTextBox] = useState(false);
  const [description, setDescription] = useState('');

  const [coords, setCoords] = useState<{ lat: number; lng: number }>(HERMOSILLO_FALLBACK_COORDS);
  const [accuracyMeters, setAccuracyMeters] = useState<number | null>(null);
  const [locationSource, setLocationSource] = useState<'gps' | 'fallback'>('fallback');
  const [locationReady, setLocationReady] = useState(false);
  const [isRefreshingLocation, setIsRefreshingLocation] = useState(false);
  const [showRefInput, setShowRefInput] = useState(false);
  const [locationRef, setLocationRef] = useState('');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [validationNotice, setValidationNotice] = useState('');
  const [confirmedReport, setConfirmedReport] = useState<CiudadanoReport | null>(null);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [downloadedConfirmation, setDownloadedConfirmation] = useState(false);
  const [isGuideOpen, setIsGuideOpen] = useState(true);
  const [isSpeakingGuide, setIsSpeakingGuide] = useState(false);

  const detectCurrentLocation = () => {
    setIsRefreshingLocation(true);
    if (typeof navigator !== 'undefined' && navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          setCoords({
            lat: pos.coords.latitude,
            lng: pos.coords.longitude,
          });
          setAccuracyMeters(
            typeof pos.coords.accuracy === 'number' ? Math.round(pos.coords.accuracy) : null,
          );
          setLocationSource('gps');
          setLocationReady(true);
          setIsRefreshingLocation(false);
        },
        () => {
          setCoords(HERMOSILLO_FALLBACK_COORDS);
          setAccuracyMeters(null);
          setLocationSource('fallback');
          setLocationReady(true);
          setIsRefreshingLocation(false);
        },
        { enableHighAccuracy: true, timeout: 12000, maximumAge: 0 },
      );
    } else {
      setLocationSource('fallback');
      setLocationReady(true);
      setIsRefreshingLocation(false);
    }
  };

  useEffect(() => {
    return () => {
      stopSpeaking();
      if (timerRef.current) {
        window.clearInterval(timerRef.current);
      }
      if (speechRecRef.current) {
        try {
          speechRecRef.current.stop();
        } catch {
          // ignore
        }
      }
      if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
        mediaRecorderRef.current.stop();
      }
    };
  }, []);

  const handleImageSelected = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setValidationNotice('');
    try {
      const compressed = await compressImageFile(file, 1280);
      setPhotoDataUrl(compressed.dataUrl);
      setPhotoBase64(compressed.base64);
      setPhotoMimeType(compressed.mimeType);
      if (!locationReady) {
        detectCurrentLocation();
      }
    } catch {
      setValidationNotice('No se pudo cargar esa foto. Intenta con otra imagen.');
    }
    e.target.value = '';
  };

  const stopRecordingInternal = () => {
    if (timerRef.current) {
      window.clearInterval(timerRef.current);
      timerRef.current = null;
    }
    if (speechRecRef.current) {
      try {
        speechRecRef.current.stop();
      } catch {
        // ignore
      }
    }
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
    }
    setIsRecording(false);
  };

  const handleToggleRecording = async () => {
    setValidationNotice('');
    setMicNotice('');

    if (isRecording) {
      stopRecordingInternal();
      return;
    }

    const win = window as unknown as {
      SpeechRecognition?: new () => SpeechRecognitionInstance;
      webkitSpeechRecognition?: new () => SpeechRecognitionInstance;
    };
    const SpeechRecCtor = win.SpeechRecognition || win.webkitSpeechRecognition;

    if (SpeechRecCtor) {
      try {
        const recognition = new SpeechRecCtor();
        recognition.lang = 'es-MX';
        recognition.continuous = true;
        recognition.interimResults = true;
        speechRecRef.current = recognition;

        recognition.onresult = (event) => {
          let transcript = '';
          for (let i = 0; i < event.results.length; i++) {
            transcript += event.results[i][0].transcript + ' ';
          }
          const clean = transcript.trim().slice(0, 1000);
          setTextoVoz(clean);
          if (clean !== '') {
            setAudioBase64('');
          }
        };

        recognition.onerror = () => {
          setMicNotice('No pudimos transcribir tu voz. Intenta de nuevo o toca "Prefiero escribir".');
          setIsRecording(false);
          if (timerRef.current) {
            window.clearInterval(timerRef.current);
            timerRef.current = null;
          }
        };

        recognition.onend = () => {
          setIsRecording(false);
          if (timerRef.current) {
            window.clearInterval(timerRef.current);
            timerRef.current = null;
          }
        };

        recognition.start();
        setIsRecording(true);
        setRecordingSeconds(0);
        timerRef.current = window.setInterval(() => {
          setRecordingSeconds((prev) => prev + 1);
        }, 1000);
        return;
      } catch {
        // Fallback a MediaRecorder
      }
    }

    if (typeof navigator === 'undefined' || !navigator.mediaDevices?.getUserMedia) {
      setMicNotice('Tu navegador no permite grabar voz. Usa el botón "Prefiero escribir".');
      setShowTextBox(true);
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const preferredMime = MediaRecorder.isTypeSupported('audio/ogg')
        ? 'audio/ogg'
        : MediaRecorder.isTypeSupported('audio/mp4')
          ? 'audio/mp4'
          : '';

      const recorder = preferredMime
        ? new MediaRecorder(stream, { mimeType: preferredMime })
        : new MediaRecorder(stream);

      audioChunksRef.current = [];
      mediaRecorderRef.current = recorder;

      recorder.ondataavailable = (ev) => {
        if (ev.data.size > 0) {
          audioChunksRef.current.push(ev.data);
        }
      };

      recorder.onstop = async () => {
        stream.getTracks().forEach((track) => track.stop());
        const mimeType = (recorder.mimeType || preferredMime || 'audio/ogg').split(';')[0];
        const blob = new Blob(audioChunksRef.current, { type: mimeType });
        if (audioUrl) {
          URL.revokeObjectURL(audioUrl);
        }
        setAudioUrl(URL.createObjectURL(blob));
        setAudioMimeType(mimeType);
        try {
          const b64 = await blobToBase64(blob);
          setAudioBase64(b64);
        } catch {
          setMicNotice('No se pudo procesar el audio. Intenta de nuevo o escribe el problema.');
        }
      };

      recorder.start();
      setIsRecording(true);
      setRecordingSeconds(0);
      timerRef.current = window.setInterval(() => {
        setRecordingSeconds((prev) => prev + 1);
      }, 1000);
    } catch {
      setMicNotice('No se pudo activar el micrófono. Puedes escribir qué pasa aquí abajo.');
      setShowTextBox(true);
    }
  };

  const handleSubmit = async () => {
    if (isRecording) {
      stopRecordingInternal();
    }

    if (!photoBase64) {
      setValidationNotice('Primero toma o sube una fotografía del problema para poder analizarlo.');
      return;
    }

    setValidationNotice('');
    setIsSubmitting(true);

    const ubicacionTexto = locationRef.trim()
      ? `${locationRef.trim()}, Hermosillo, Sonora`
      : `Hermosillo, Sonora (${coords.lat.toFixed(3)}, ${coords.lng.toFixed(3)})`;

    try {
      const response = await fetch(API_ENDPOINTS.analizar, {
        method: 'POST',
        headers: buildApiHeaders(),
        body: JSON.stringify({
          imagen_base64: photoBase64,
          imagen_mime: photoMimeType,
          texto_voz: textoVoz.trim().slice(0, 1000),
          descripcion_manual: description.trim().slice(0, 1000),
          audio_base64:
            textoVoz.trim() === '' &&
            ['audio/ogg', 'audio/mpeg', 'audio/wav', 'audio/aac', 'audio/flac'].includes(audioMimeType)
              ? audioBase64
              : '',
          audio_mime: audioMimeType,
          lat: coords.lat,
          lng: coords.lng,
          colonia: 'Hermosillo',
          ubicacion_texto: ubicacionTexto,
          guardar: true,
        }),
      });

      const json = await response.json().catch(() => null);
      if (!response.ok || !json?.ok) {
        const msg = json?.message || getFriendlyHttpMessage(response.status);
        setValidationNotice(msg);
        return;
      }

      const analisis = json.analisis as AnalisisResponseData;
      const folio = (json.folio as string | null) || `RC-LOCAL-${Date.now()}`;
      const oficioTexto = formatReporteFormalText(analisis, folio);

      const newReport: CiudadanoReport = {
        id: `rep-${Date.now()}`,
        folio,
        fecha: new Date().toISOString(),
        colonia: 'Hermosillo',
        ubicacion_texto: analisis.reporte_formal.ubicacion || ubicacionTexto,
        lat: typeof json.lat === 'number' ? json.lat : Number(coords.lat.toFixed(3)),
        lng: typeof json.lng === 'number' ? json.lng : Number(coords.lng.toFixed(3)),
        fuera_de_zona: Boolean(json.fuera_de_zona),
        fotoDataUrl: photoDataUrl || undefined,
        detalles_usuario: [textoVoz.trim(), description.trim()].filter(Boolean).join(' · ') || undefined,
        dependencia: analisis.dependencia,
        nivel_riesgo: analisis.riesgo,
        accesibilidad_espacio: analisis.riesgo === 'Alto' ? 'Peligroso' : 'Con obstáculos',
        motivo_riesgo: analisis.motivo_riesgo,
        confianza_dependencia: analisis.confianza_dependencia,
        resumen_problema: analisis.resumen_corto,
        reporte_formal: analisis.reporte_formal,
        oficio_formal: oficioTexto,
        mensaje_ciudadano: analisis.mensaje_usuario,
        alerta_preventiva: analisis.motivo_riesgo,
        estado: 'Listo para compartir o entregar',
        esPropio: true,
      };

      onReportCreated(newReport);
      setConfirmedReport(newReport);

      speakSpanish(`${analisis.mensaje_usuario}`, {
        onStart: () => setIsSpeaking(true),
        onEnd: () => setIsSpeaking(false),
      });
    } catch {
      setValidationNotice('Sin conexión a internet. Verifica tu señal e intenta de nuevo.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleToggleSpeech = () => {
    if (!confirmedReport) return;
    if (isSpeaking) {
      stopSpeaking();
      setIsSpeaking(false);
      return;
    }

    const spokenText = `Folio ${confirmedReport.folio}. ${confirmedReport.mensaje_ciudadano}`;
    speakSpanish(spokenText, {
      onStart: () => setIsSpeaking(true),
      onEnd: () => setIsSpeaking(false),
    });
  };

  const getWhatsAppShareUrl = (report: CiudadanoReport) => {
    const shareText = `${report.oficio_formal}\n\nUbicación aproximada: https://www.google.com/maps?q=${report.lat},${report.lng}`;
    return `https://wa.me/?text=${encodeURIComponent(shareText)}`;
  };

  const handleShareReport = async (report: CiudadanoReport) => {
    const shareText = `${report.oficio_formal}\n\nUbicación aproximada: https://www.google.com/maps?q=${report.lat},${report.lng}`;
    if (typeof navigator !== 'undefined' && navigator.share) {
      try {
        await navigator.share({
          title: `Reporte Ciudadano ${report.folio}`,
          text: shareText,
        });
        return;
      } catch {
        // Cae a enlace directo de WhatsApp
      }
    }
    const link = document.createElement('a');
    link.href = getWhatsAppShareUrl(report);
    link.target = '_blank';
    link.rel = 'noopener noreferrer';
    document.body.appendChild(link);
    link.click();
    link.remove();
  };

  const handleReset = () => {
    stopSpeaking();
    setIsSpeaking(false);
    setConfirmedReport(null);
    setPhotoDataUrl('');
    setPhotoBase64('');
    setTextoVoz('');
    setAudioUrl('');
    setAudioBase64('');
    setDescription('');
    setShowTextBox(false);
    setMicNotice('');
    setValidationNotice('');
    setDownloadedConfirmation(false);
    setLocationRef('');
    setShowRefInput(false);
  };

  const handleDownloadOficio = () => {
    if (!confirmedReport) return;
    downloadOficioTxt(confirmedReport);
    setDownloadedConfirmation(true);
    window.setTimeout(() => setDownloadedConfirmation(false), 3000);
  };

  const handleToggleGuideSpeech = () => {
    if (isSpeakingGuide) {
      stopSpeaking();
      setIsSpeakingGuide(false);
      return;
    }
    speakSpanish(
      'Bienvenido a Reporte Ciudadano HMO. Paso 1: toma una foto del problema. Paso 2: toca Contar qué pasa para explicarlo con tu voz. Paso 3: presiona Enviar Reporte para generar tu folio y compartirlo.',
      {
        onStart: () => setIsSpeakingGuide(true),
        onEnd: () => setIsSpeakingGuide(false),
      },
    );
  };

  if (confirmedReport) {
    return (
      <section aria-labelledby="confirm-title" className="space-y-5">
        <div className="rounded-2xl border-2 border-[#166534] bg-white p-6 shadow-sm">
          <div className="flex items-center gap-3 text-[#166534]">
            <CheckCircle2 className="h-9 w-9 shrink-0" aria-hidden="true" />
            <h2 id="confirm-title" className="text-[24px] font-extrabold text-[#111827]">
              ¡Reporte Listo para Compartir!
            </h2>
          </div>

          <div className="mt-4 rounded-xl border-2 border-[#D6D3CD] bg-[#FAF8F5] p-4">
            <p className="text-[18px] font-bold text-[#374151]">Folio generado</p>
            <p className="tabular-nums text-[28px] font-extrabold tracking-tight text-[#0F2C59]">
              {confirmedReport.folio}
            </p>
          </div>

          <div className="mt-4 space-y-2 text-[18px] text-[#111827]">
            <p>
              <span className="font-bold">Problema:</span> {confirmedReport.resumen_problema}
            </p>
            <p>
              <span className="font-bold">Ubicación:</span> {confirmedReport.ubicacion_texto}
            </p>
            <p>
              <span className="font-bold">Dependencia probable:</span> {confirmedReport.dependencia}
            </p>
            <p className="flex items-center gap-2 font-bold">
              <AlertTriangle
                className={`h-5 w-5 shrink-0 ${
                  confirmedReport.nivel_riesgo === 'Alto'
                    ? 'text-[#B91C1C]'
                    : confirmedReport.nivel_riesgo === 'Medio'
                      ? 'text-[#C2410C]'
                      : 'text-[#166534]'
                }`}
                aria-hidden="true"
              />
              <span>Riesgo {confirmedReport.nivel_riesgo}</span>
            </p>
          </div>

          <div className="mt-5 rounded-xl bg-[#EEF2F8] p-4">
            <p className="text-[20px] font-bold leading-snug text-[#111827]">
              {confirmedReport.mensaje_ciudadano}
            </p>
          </div>

          <button
            type="button"
            onClick={handleToggleSpeech}
            className="mt-5 flex min-h-[72px] w-full items-center justify-center gap-3 rounded-2xl bg-[#0F2C59] px-5 py-4 text-[22px] font-bold text-white hover:bg-[#0A1F40]"
          >
            {isSpeaking ? (
              <>
                <VolumeX className="h-7 w-7 shrink-0" aria-hidden="true" />
                <span>Detener confirmación</span>
              </>
            ) : (
              <>
                <Volume2 className="h-7 w-7 shrink-0" aria-hidden="true" />
                <span>Escuchar confirmación</span>
              </>
            )}
          </button>

          <div className="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-2">
            <button
              type="button"
              onClick={() => handleShareReport(confirmedReport)}
              className="flex min-h-[64px] w-full items-center justify-center gap-3 rounded-2xl bg-[#166534] px-5 py-3 text-[22px] font-bold text-white hover:bg-[#14532D]"
            >
              <Share2 className="h-7 w-7 shrink-0" aria-hidden="true" />
              <span>Compartir reporte</span>
            </button>
            <a
              href={getWhatsAppShareUrl(confirmedReport)}
              target="_blank"
              rel="noopener noreferrer"
              className="flex min-h-[64px] w-full items-center justify-center gap-2 rounded-2xl border-2 border-[#166534] bg-[#ECFDF5] px-5 py-3 text-center text-[22px] font-bold text-[#14532D] hover:bg-[#DCFCE7]"
            >
              <span>Enviar por WhatsApp</span>
            </a>
          </div>

          <div className="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-2">
            <button
              type="button"
              onClick={handleDownloadOficio}
              className={`flex min-h-[60px] w-full items-center justify-center gap-2 rounded-xl border-2 px-4 py-3 text-[22px] font-bold ${
                downloadedConfirmation
                  ? 'border-[#166534] bg-[#DCFCE7] text-[#166534]'
                  : 'border-[#374151] bg-[#FAF8F5] text-[#111827] hover:bg-[#EFECE6]'
              }`}
            >
              {downloadedConfirmation ? (
                <>
                  <Check className="h-6 w-6 shrink-0" aria-hidden="true" />
                  <span>Oficio descargado</span>
                </>
              ) : (
                <>
                  <Download className="h-6 w-6 shrink-0" aria-hidden="true" />
                  <span>Descargar Oficio</span>
                </>
              )}
            </button>

            <button
              type="button"
              onClick={() => onPrintReport(confirmedReport)}
              className="flex min-h-[60px] w-full items-center justify-center gap-2 rounded-xl border-2 border-[#374151] bg-[#FAF8F5] px-4 py-3 text-[22px] font-bold text-[#111827] hover:bg-[#EFECE6]"
            >
              <Printer className="h-6 w-6 shrink-0" aria-hidden="true" />
              <span>Imprimir / PDF</span>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <button
            type="button"
            onClick={onGoToMyReports}
            className="flex min-h-[60px] w-full items-center justify-center gap-2 rounded-xl border-2 border-[#0F2C59] bg-white px-4 py-3 text-[22px] font-bold text-[#0F2C59] hover:bg-[#EEF2F8]"
          >
            <ClipboardList className="h-6 w-6 shrink-0" aria-hidden="true" />
            <span>Mis Reportes</span>
          </button>

          <button
            type="button"
            onClick={handleReset}
            className="flex min-h-[60px] w-full items-center justify-center gap-2 rounded-xl border-2 border-[#374151] bg-white px-4 py-3 text-[22px] font-bold text-[#111827] hover:bg-[#EFECE6]"
          >
            <RotateCcw className="h-6 w-6 shrink-0" aria-hidden="true" />
            <span>Nuevo Reporte</span>
          </button>
        </div>
      </section>
    );
  }

  return (
    <section aria-labelledby="capture-heading" className="space-y-5">
      <div className="rounded-2xl border-2 border-[#0F2C59] bg-white p-5 space-y-3">
        <div className="flex flex-wrap items-start justify-between gap-2">
          <h2 className="text-[22px] font-extrabold leading-snug text-[#0F2C59]">
            Bienvenido al portal de denuncia ciudadana
          </h2>
          <button
            type="button"
            onClick={() => setIsGuideOpen((prev) => !prev)}
            className="text-[18px] font-bold text-[#0F2C59] underline"
          >
            {isGuideOpen ? 'Ocultar guía' : 'Ver instrucciones'}
          </button>
        </div>

        <p className="text-[18px] leading-relaxed text-[#111827]">
          Esta aplicación te ayuda a generar un reporte formal con foto, voz y ubicación en
          Hermosillo para que puedas guardarlo o compartirlo (no se envía automáticamente al
          municipio).
        </p>

        {isGuideOpen && (
          <div className="space-y-3 pt-1">
            <ol className="space-y-2 rounded-xl bg-[#EEF2F8] p-4 text-[18px] leading-relaxed text-[#111827]">
              <li>
                <span className="font-extrabold text-[#0F2C59]">1. Toma una foto:</span> muestra el
                obstáculo o falla en la vía pública.
              </li>
              <li>
                <span className="font-extrabold text-[#0F2C59]">2. Cuenta qué pasa:</span> usa el
                micrófono para dictar o graba un mensaje de voz.
              </li>
              <li>
                <span className="font-extrabold text-[#0F2C59]">3. Envía para analizar:</span>{' '}
                recibirás tu folio, lectura en voz alta y botón para compartir.
              </li>
            </ol>

            <button
              type="button"
              onClick={handleToggleGuideSpeech}
              className="flex min-h-[58px] w-full items-center justify-center gap-2.5 rounded-xl border-2 border-[#0F2C59] bg-[#FAF8F5] px-4 py-3 text-[22px] font-bold text-[#0F2C59] hover:bg-[#EEF2F8]"
            >
              {isSpeakingGuide ? (
                <>
                  <VolumeX className="h-6 w-6 shrink-0" aria-hidden="true" />
                  <span>Detener guía en voz</span>
                </>
              ) : (
                <>
                  <Volume2 className="h-6 w-6 shrink-0" aria-hidden="true" />
                  <span>Escuchar instrucciones</span>
                </>
              )}
            </button>
          </div>
        )}
      </div>

      <div className="rounded-2xl border-2 border-[#D6D3CD] bg-white p-4 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2.5">
            <MapPin className="h-6 w-6 shrink-0 text-[#166534]" aria-hidden="true" />
            <span className="text-[18px] font-extrabold text-[#111827]">
              {isRefreshingLocation
                ? 'Obteniendo ubicación...'
                : locationSource === 'gps'
                  ? 'Ubicación GPS detectada'
                  : 'Ubicación aproximada en Hermosillo'}
            </span>
          </div>

          <button
            type="button"
            onClick={detectCurrentLocation}
            disabled={isRefreshingLocation}
            className="flex min-h-[44px] items-center gap-1.5 rounded-xl border-2 border-[#0F2C59] bg-[#EEF2F8] px-3.5 py-1.5 text-[18px] font-bold text-[#0F2C59] hover:bg-[#DCE6F5] disabled:opacity-60"
          >
            <RefreshCw
              className={`h-4 w-4 shrink-0 ${isRefreshingLocation ? 'animate-spin' : ''}`}
              aria-hidden="true"
            />
            <span>{locationReady ? 'Actualizar GPS' : 'Detectar ubicación'}</span>
          </button>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-2 text-[18px] text-[#374151]">
          <span className="tabular-nums">
            {coords.lat.toFixed(3)}, {coords.lng.toFixed(3)}
            {accuracyMeters !== null ? ` · Precisión ± ${accuracyMeters} m` : ''}
          </span>

          <a
            href={`https://www.google.com/maps?q=${coords.lat},${coords.lng}`}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 font-bold text-[#0F2C59] underline"
          >
            <ExternalLink className="h-4 w-4 shrink-0" aria-hidden="true" />
            <span>Ver punto exacto</span>
          </a>
        </div>

        <div>
          <button
            type="button"
            onClick={() => setShowRefInput((prev) => !prev)}
            className="text-[18px] font-bold text-[#0F2C59] underline"
          >
            {showRefInput ? 'Ocultar referencia' : 'Agregar calle o referencia (opcional)'}
          </button>

          {showRefInput && (
            <div className="mt-2">
              <label htmlFor="location-ref-input" className="mb-1 block text-[18px] font-bold text-[#111827]">
                Calle o esquina de referencia:
              </label>
              <input
                id="location-ref-input"
                type="text"
                maxLength={200}
                value={locationRef}
                onChange={(e) => setLocationRef(e.target.value)}
                placeholder="Ej. Rosales y Av. Serdán, frente a farmacia"
                className="w-full rounded-xl border-2 border-[#374151] bg-[#FAF8F5] px-3.5 py-2.5 text-[18px] text-[#111827]"
              />
            </div>
          )}
        </div>
      </div>

      <h2 id="capture-heading" className="sr-only">
        Captura de reporte ciudadano
      </h2>

      <div className="rounded-2xl border-2 border-[#D6D3CD] bg-white p-5">
        <input
          ref={cameraInputRef}
          type="file"
          accept="image/*"
          capture="environment"
          onChange={handleImageSelected}
          className="hidden"
          aria-label="Tomar foto con cámara"
        />
        <input
          ref={galleryInputRef}
          type="file"
          accept="image/*"
          onChange={handleImageSelected}
          className="hidden"
          aria-label="Elegir foto guardada"
        />

        {!photoDataUrl ? (
          <div className="space-y-3">
            <button
              type="button"
              onClick={() => cameraInputRef.current?.click()}
              className="flex min-h-[88px] w-full items-center justify-center gap-3 rounded-2xl bg-[#0F2C59] px-5 py-4 text-center text-[22px] font-bold text-white shadow-sm hover:bg-[#0A1F40]"
            >
              <Camera className="h-8 w-8 shrink-0" aria-hidden="true" />
              <span>1. Tomar Foto del Problema</span>
            </button>

            <button
              type="button"
              onClick={() => galleryInputRef.current?.click()}
              className="flex min-h-[54px] w-full items-center justify-center gap-2 rounded-xl border-2 border-[#D6D3CD] bg-[#FAF8F5] px-4 py-2.5 text-[18px] font-bold text-[#111827] hover:bg-[#EFECE6]"
            >
              <ImagePlus className="h-5 w-5 shrink-0" aria-hidden="true" />
              <span>O subir foto guardada</span>
            </button>
          </div>
        ) : (
          <div className="space-y-3">
            <p className="text-[18px] font-bold text-[#166534]">1. Foto lista</p>
            <div className="overflow-hidden rounded-xl border-2 border-[#D6D3CD] bg-[#EFECE6]">
              <img
                src={photoDataUrl}
                alt="Vista previa del problema urbano"
                className="aspect-[4/3] w-full object-cover"
              />
            </div>
            <button
              type="button"
              onClick={() => cameraInputRef.current?.click()}
              className="flex min-h-[58px] w-full items-center justify-center gap-2 rounded-xl border-2 border-[#0F2C59] bg-white px-4 py-3 text-[22px] font-bold text-[#0F2C59] hover:bg-[#EEF2F8]"
            >
              <Camera className="h-6 w-6 shrink-0" aria-hidden="true" />
              <span>Cambiar foto</span>
            </button>
          </div>
        )}
      </div>

      <div className="rounded-2xl border-2 border-[#D6D3CD] bg-white p-5 space-y-4">
        <button
          type="button"
          onClick={handleToggleRecording}
          className={`flex min-h-[88px] w-full items-center justify-center gap-3 rounded-2xl px-5 py-4 text-center text-[22px] font-bold text-white shadow-sm ${
            isRecording ? 'bg-[#B91C1C] hover:bg-[#991B1B]' : 'bg-[#0F2C59] hover:bg-[#0A1F40]'
          }`}
        >
          {isRecording ? (
            <>
              <Square className="h-7 w-7 shrink-0 fill-current" aria-hidden="true" />
              <span className="tabular-nums">
                Escuchando ({recordingSeconds}s) · Tocar para parar
              </span>
            </>
          ) : (
            <>
              <Mic className="h-8 w-8 shrink-0" aria-hidden="true" />
              <span>2. Contar qué pasa</span>
            </>
          )}
        </button>

        {textoVoz && (
          <div className="rounded-xl border border-[#166534] bg-[#F0FDF4] p-3 text-[18px] text-[#111827]">
            <p className="font-bold text-[#166534]">Lo que dictaste por voz:</p>
            <p className="mt-1">{textoVoz}</p>
          </div>
        )}

        {audioUrl && !textoVoz && !isRecording && (
          <div className="rounded-xl border border-[#D6D3CD] bg-[#FAF8F5] p-3 space-y-2">
            <p className="text-[18px] font-bold text-[#166534]">Audio grabado correctamente</p>
            <audio controls src={audioUrl} className="w-full" />
          </div>
        )}

        {micNotice && (
          <p className="rounded-xl border border-[#C2410C] bg-orange-50 px-4 py-3 text-[18px] font-bold text-[#9A3412]">
            {micNotice}
          </p>
        )}

        <div>
          <button
            type="button"
            onClick={() => setShowTextBox((prev) => !prev)}
            className="flex min-h-[50px] items-center gap-2 rounded-xl border-2 border-[#D6D3CD] bg-[#FAF8F5] px-4 py-2 text-[18px] font-bold text-[#111827] hover:bg-[#EFECE6]"
          >
            <Keyboard className="h-5 w-5 shrink-0" aria-hidden="true" />
            <span>{showTextBox ? 'Ocultar cuadro de texto' : 'Prefiero escribir'}</span>
          </button>

          {showTextBox && (
            <div className="mt-3">
              <label htmlFor="manual-description" className="mb-2 block text-[18px] font-bold text-[#111827]">
                Escriba brevemente qué ocurre (máx. 1000 caracteres):
              </label>
              <textarea
                id="manual-description"
                rows={3}
                maxLength={1000}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Ejemplo: La banqueta está levantada frente a la esquina..."
                className="w-full rounded-xl border-2 border-[#374151] bg-[#FAF8F5] p-3.5 text-[18px] text-[#111827]"
              />
            </div>
          )}
        </div>
      </div>

      {validationNotice && (
        <div
          role="alert"
          className="flex items-start gap-3 rounded-xl border-2 border-[#C2410C] bg-orange-50 p-4 text-[18px] font-bold text-[#9A3412]"
        >
          <AlertTriangle className="mt-0.5 h-6 w-6 shrink-0" aria-hidden="true" />
          <span>{validationNotice}</span>
        </div>
      )}

      <button
        type="button"
        disabled={isSubmitting}
        onClick={handleSubmit}
        className="flex min-h-[76px] w-full items-center justify-center gap-3 rounded-2xl bg-[#166534] px-6 py-4 text-[22px] font-extrabold text-white shadow-md hover:bg-[#14532D] disabled:opacity-75"
      >
        {isSubmitting ? (
          <>
            <Loader2 className="h-7 w-7 shrink-0 animate-spin" aria-hidden="true" />
            <span>Analizando tu reporte…</span>
          </>
        ) : (
          <>
            <Send className="h-7 w-7 shrink-0" aria-hidden="true" />
            <span>Enviar Reporte</span>
          </>
        )}
      </button>
    </section>
  );
}
