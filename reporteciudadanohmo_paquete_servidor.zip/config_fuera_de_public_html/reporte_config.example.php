<?php
declare(strict_types=1);

// Subir FUERA de public_html en: /home2/beceacbf/config/reporte_config.php (permisos 600)
// El capitán captura las claves reales directamente en el servidor.

define('GEMINI_API_KEY', 'CAMBIAR'); // API key del equipo: Google AI Studio -> Get API key (cuenta del equipo)
define('GEMINI_MODEL', 'CAMBIAR');   // Nombre exacto del modelo en AI Studio -> Get code (ej. gemini-2.5-flash o el modelo activo)

define('DB_HOST', 'localhost');
define('DB_NAME', 'beceacbf_reporteciudadanohmo');
define('DB_USER', 'beceacbf_reporteciudadanoadmin');
define('DB_PASS', 'CAMBIAR');

define('APP_TOKEN', 'CAMBIAR');       // Cadena aleatoria larga (40+ caracteres), compartida con Flutter y la app Web

define('ALLOWED_ORIGINS', [
    'http://localhost:5173',
    'http://localhost:3000',
]);

define('MAX_IMAGE_BYTES', 1572864);    // 1.5 MB
define('MAX_AUDIO_BYTES', 2097152);    // 2 MB
define('RATE_LIMIT_PER_MIN', 15);
define('ALERTAS_CACHE_MIN', 10);
