CREATE TABLE IF NOT EXISTS reportes (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  folio VARCHAR(32) NOT NULL,
  tipo_obstaculo VARCHAR(160) NOT NULL,
  riesgo ENUM('Alto', 'Medio', 'Bajo') NOT NULL DEFAULT 'Medio',
  motivo_riesgo VARCHAR(500) NOT NULL,
  dependencia ENUM(
    'Obras Públicas / CIDUE',
    'Alumbrado Público',
    'Agua de Hermosillo',
    'Servicios Públicos',
    'Protección Civil'
  ) NOT NULL,
  confianza_dependencia ENUM('Alta', 'Media', 'Baja') NOT NULL DEFAULT 'Media',
  resumen_corto VARCHAR(220) NOT NULL,
  reporte_formal_json JSON NOT NULL,
  mensaje_usuario TEXT NOT NULL,
  colonia VARCHAR(120) NOT NULL DEFAULT 'Hermosillo',
  ubicacion_texto VARCHAR(255) NOT NULL,
  lat DECIMAL(6, 3) NOT NULL,
  lng DECIMAL(6, 3) NOT NULL,
  fuera_de_zona TINYINT(1) NOT NULL DEFAULT 0,
  es_demo TINYINT(1) NOT NULL DEFAULT 0,
  activo TINYINT(1) NOT NULL DEFAULT 1,
  creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_reportes_folio (folio),
  KEY idx_reportes_activo_riesgo_fecha (activo, riesgo, creado_en),
  KEY idx_reportes_coords (lat, lng)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS alertas_cache (
  zona_clave VARCHAR(32) NOT NULL,
  respuesta_json JSON NOT NULL,
  actualizado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (zona_clave),
  KEY idx_alertas_actualizado (actualizado_en)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS rate_limit (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  ip_hash CHAR(64) NOT NULL,
  endpoint VARCHAR(40) NOT NULL,
  creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_rate_lookup (ip_hash, endpoint, creado_en),
  KEY idx_rate_cleanup (creado_en)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
