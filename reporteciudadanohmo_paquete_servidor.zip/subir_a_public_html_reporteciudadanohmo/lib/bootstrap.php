<?php
declare(strict_types=1);

ini_set('display_errors', '0');
ini_set('log_errors', '1');
error_reporting(E_ALL);
date_default_timezone_set('America/Hermosillo');

const REPORTE_CONFIG_PATH = '/home2/beceacbf/config/reporte_config.php';
const CANONICAL_ORIGIN = 'https://clubdecienciafronteriza.com';

function json_response(int $status, array $payload): never
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('X-Content-Type-Options: nosniff');
    header('Cache-Control: no-store, no-cache, must-revalidate');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

set_exception_handler(static function (Throwable $e): void {
    error_log('[ReporteCiudadanoHMO] Uncaught exception: ' . $e->getMessage());
    json_response(500, [
        'ok' => false,
        'error' => 'server_error',
        'message' => 'Ocurrió un error interno en el servidor. Intenta de nuevo en unos momentos.',
    ]);
});

if (!is_file(REPORTE_CONFIG_PATH)) {
    json_response(500, [
        'ok' => false,
        'error' => 'config_missing',
    ]);
}

$loadedConfig = require REPORTE_CONFIG_PATH;
/** @var array<string, mixed> $CONFIG */
$CONFIG = is_array($loadedConfig) ? $loadedConfig : [];
$configKeys = [
    'GEMINI_API_KEY',
    'GEMINI_MODEL',
    'DB_HOST',
    'DB_NAME',
    'DB_USER',
    'DB_PASS',
    'APP_TOKEN',
    'ALLOWED_ORIGINS',
    'MAX_IMAGE_BYTES',
    'MAX_AUDIO_BYTES',
    'RATE_LIMIT_PER_MIN',
    'ALERTAS_CACHE_MIN',
];
foreach ($configKeys as $cfgKey) {
    if (defined($cfgKey)) {
        $CONFIG[$cfgKey] = constant($cfgKey);
    }
}

$requestOrigin = $_SERVER['HTTP_ORIGIN'] ?? '';
$allowedOrigins = is_array($CONFIG['ALLOWED_ORIGINS'] ?? null) ? $CONFIG['ALLOWED_ORIGINS'] : [];
$allowedOrigins[] = CANONICAL_ORIGIN;

if ($requestOrigin !== '' && in_array($requestOrigin, $allowedOrigins, true)) {
    header('Access-Control-Allow-Origin: ' . $requestOrigin);
    header('Vary: Origin');
    header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, X-App-Token');
    header('Access-Control-Max-Age: 600');
}

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'OPTIONS') {
    http_response_code(204);
    exit;
}

function get_pdo(array $config): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) {
        return $pdo;
    }

    $host = (string) ($config['DB_HOST'] ?? 'localhost');
    $db = (string) ($config['DB_NAME'] ?? '');
    $user = (string) ($config['DB_USER'] ?? '');
    $pass = (string) ($config['DB_PASS'] ?? '');

    $dsn = "mysql:host={$host};dbname={$db};charset=utf8mb4";
    $pdo = new PDO($dsn, $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
    $pdo->exec("SET time_zone = '-07:00'");

    return $pdo;
}

function get_header_token(): string
{
    if (!empty($_SERVER['HTTP_X_APP_TOKEN'])) {
        return trim((string) $_SERVER['HTTP_X_APP_TOKEN']);
    }
    if (function_exists('getallheaders')) {
        foreach (getallheaders() as $name => $value) {
            if (strcasecmp((string) $name, 'X-App-Token') === 0) {
                return trim((string) $value);
            }
        }
    }
    return '';
}

function require_app_token(array $config): void
{
    $expected = (string) ($config['APP_TOKEN'] ?? '');
    $provided = get_header_token();

    if ($expected === '' || $expected === 'CAMBIAR' || $provided === '' || !hash_equals($expected, $provided)) {
        json_response(401, [
            'ok' => false,
            'error' => 'unauthorized',
            'message' => 'No pudimos validar el acceso de la aplicación. Recarga la página e intenta de nuevo.',
        ]);
    }
}

function enforce_rate_limit(PDO $pdo, array $config, string $endpoint): void
{
    $limit = max(1, (int) ($config['RATE_LIMIT_PER_MIN'] ?? 15));
    $ip = (string) ($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0');
    $salt = (string) ($config['APP_TOKEN'] ?? 'hmo');
    $ipHash = hash('sha256', $ip . '|' . $salt);

    try {
        $cleanup = $pdo->prepare('DELETE FROM rate_limit WHERE creado_en < DATE_SUB(NOW(), INTERVAL 5 MINUTE)');
        $cleanup->execute();

        $check = $pdo->prepare(
            'SELECT COUNT(*) AS total FROM rate_limit WHERE ip_hash = :ip_hash AND endpoint = :endpoint AND creado_en >= DATE_SUB(NOW(), INTERVAL 1 MINUTE)'
        );
        $check->execute([
            ':ip_hash' => $ipHash,
            ':endpoint' => $endpoint,
        ]);
        $row = $check->fetch();
        $total = (int) ($row['total'] ?? 0);

        if ($total >= $limit) {
            json_response(429, [
                'ok' => false,
                'error' => 'rate_limited',
                'message' => 'Has enviado muchas solicitudes seguidas. Por favor espera un minuto antes de volver a intentar.',
            ]);
        }

        $insert = $pdo->prepare('INSERT INTO rate_limit (ip_hash, endpoint) VALUES (:ip_hash, :endpoint)');
        $insert->execute([
            ':ip_hash' => $ipHash,
            ':endpoint' => $endpoint,
        ]);
    } catch (Throwable $e) {
        error_log('[ReporteCiudadanoHMO] Rate limit error: ' . $e->getMessage());
    }
}

function read_json_body(): array
{
    $raw = file_get_contents('php://input');
    if ($raw === false || trim($raw) === '') {
        return [];
    }
    $decoded = json_decode($raw, true);
    if (!is_array($decoded)) {
        json_response(422, [
            'ok' => false,
            'error' => 'invalid_json',
            'message' => 'El formato de los datos enviados no es válido.',
        ]);
    }
    return $decoded;
}
