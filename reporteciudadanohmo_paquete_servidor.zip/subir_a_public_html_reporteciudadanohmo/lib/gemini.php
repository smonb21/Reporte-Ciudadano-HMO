<?php
declare(strict_types=1);

const GEMINI_ALLOWED_IMAGE_MIMES = ['image/jpeg', 'image/png', 'image/webp'];
const GEMINI_ALLOWED_AUDIO_MIMES = ['audio/ogg', 'audio/mpeg', 'audio/wav', 'audio/aac', 'audio/flac'];

function gemini_generar(
    array $config,
    string $systemInstruction,
    array $parts,
    array $responseSchema,
    float $temperature = 0.3
): array {
    $apiKey = trim((string) ($config['GEMINI_API_KEY'] ?? ''));
    $model = trim((string) ($config['GEMINI_MODEL'] ?? ''));

    if ($apiKey === '' || $apiKey === 'CAMBIAR' || $model === '' || $model === 'CAMBIAR') {
        throw new RuntimeException('gemini_config_missing');
    }

    $sanitizedParts = [];
    foreach ($parts as $part) {
        if (isset($part['text'])) {
            $sanitizedParts[] = ['text' => (string) $part['text']];
            continue;
        }
        if (isset($part['inlineData']) && is_array($part['inlineData'])) {
            $mime = strtolower(trim((string) ($part['inlineData']['mimeType'] ?? '')));
            $data = (string) ($part['inlineData']['data'] ?? '');
            $isAllowedImage = in_array($mime, GEMINI_ALLOWED_IMAGE_MIMES, true);
            $isAllowedAudio = in_array($mime, GEMINI_ALLOWED_AUDIO_MIMES, true);
            if (($isAllowedImage || $isAllowedAudio) && $data !== '') {
                $sanitizedParts[] = [
                    'inlineData' => [
                        'mimeType' => $mime,
                        'data' => $data,
                    ],
                ];
            }
        }
    }

    if ($sanitizedParts === []) {
        throw new RuntimeException('gemini_empty');
    }

    $endpoint = sprintf(
        'https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent',
        rawurlencode($model)
    );

    $payload = [
        'systemInstruction' => [
            'parts' => [
                ['text' => $systemInstruction],
            ],
        ],
        'contents' => [
            [
                'role' => 'user',
                'parts' => $sanitizedParts,
            ],
        ],
        'generationConfig' => [
            'temperature' => $temperature,
            'maxOutputTokens' => 1500,
            'responseMimeType' => 'application/json',
            'responseSchema' => $responseSchema,
        ],
    ];

    $jsonBody = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($jsonBody === false) {
        throw new RuntimeException('gemini_bad_json');
    }

    $ch = curl_init($endpoint);
    if ($ch === false) {
        throw new RuntimeException('gemini_http_500');
    }

    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json',
            'x-goog-api-key: ' . $apiKey,
        ],
        CURLOPT_POSTFIELDS => $jsonBody,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_TIMEOUT => 60,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
    ]);

    $rawResponse = curl_exec($ch);
    $curlErrno = curl_errno($ch);
    $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($curlErrno === CURLE_OPERATION_TIMEDOUT || $curlErrno === 28) {
        throw new RuntimeException('gemini_timeout');
    }

    if ($rawResponse === false || $curlErrno !== 0) {
        throw new RuntimeException('gemini_http_' . ($httpCode > 0 ? $httpCode : 502));
    }

    if ($httpCode >= 400) {
        throw new RuntimeException('gemini_http_' . $httpCode);
    }

    $decoded = json_decode((string) $rawResponse, true);
    if (!is_array($decoded)) {
        throw new RuntimeException('gemini_bad_json');
    }

    if (!empty($decoded['promptFeedback']['blockReason'])) {
        throw new RuntimeException('gemini_blocked');
    }

    $candidate = $decoded['candidates'][0] ?? null;
    if (!is_array($candidate)) {
        throw new RuntimeException('gemini_empty');
    }

    $finishReason = (string) ($candidate['finishReason'] ?? '');
    if (in_array($finishReason, ['SAFETY', 'RECITATION', 'PROHIBITED_CONTENT', 'BLOCKLIST'], true)) {
        throw new RuntimeException('gemini_blocked');
    }

    $textOut = '';
    $candidateParts = $candidate['content']['parts'] ?? [];
    if (is_array($candidateParts)) {
        foreach ($candidateParts as $cp) {
            if (isset($cp['text'])) {
                $textOut .= (string) $cp['text'];
            }
        }
    }

    $textOut = trim($textOut);
    if ($textOut === '') {
        throw new RuntimeException('gemini_empty');
    }

    $textOut = preg_replace('/^```json\s*/i', '', $textOut) ?? $textOut;
    $textOut = preg_replace('/\s*```$/', '', $textOut) ?? $textOut;

    $parsed = json_decode(trim($textOut), true);
    if (!is_array($parsed)) {
        throw new RuntimeException('gemini_bad_json');
    }

    return $parsed;
}
