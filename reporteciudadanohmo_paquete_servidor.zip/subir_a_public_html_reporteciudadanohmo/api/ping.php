<?php
declare(strict_types=1);

require_once __DIR__ . '/../lib/bootstrap.php';

$configOk = is_file(REPORTE_CONFIG_PATH)
    && !empty($CONFIG['GEMINI_API_KEY']) && $CONFIG['GEMINI_API_KEY'] !== 'CAMBIAR'
    && !empty($CONFIG['GEMINI_MODEL']) && $CONFIG['GEMINI_MODEL'] !== 'CAMBIAR'
    && !empty($CONFIG['APP_TOKEN']) && $CONFIG['APP_TOKEN'] !== 'CAMBIAR';

$dbOk = false;
try {
    $pdo = get_pdo($CONFIG);
    $stmt = $pdo->query('SELECT 1');
    $dbOk = $stmt !== false;
} catch (Throwable $e) {
    error_log('[ReporteCiudadanoHMO] Ping DB check failed: ' . $e->getMessage());
    $dbOk = false;
}

$horaHermosillo = (new DateTimeImmutable('now', new DateTimeZone('America/Hermosillo')))->format('c');

json_response(200, [
    'ok' => true,
    'php' => PHP_VERSION,
    'db' => $dbOk,
    'curl' => function_exists('curl_init'),
    'config' => $configOk,
    'hora_servidor' => $horaHermosillo,
]);
