<?php
declare(strict_types=1);

require_once __DIR__ . '/../lib/bootstrap.php';
require_once __DIR__ . '/../lib/gemini.php';

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    json_response(405, [
        'ok' => false,
        'error' => 'method_not_allowed',
        'message' => 'Método no permitido.',
    ]);
}

require_app_token($CONFIG);
$pdo = get_pdo($CONFIG);
enforce_rate_limit($pdo, $CONFIG, 'analizar');

$body = read_json_body();

$imagenBase64Raw = trim((string) ($body['imagen_base64'] ?? ''));
$imagenMime = strtolower(trim((string) ($body['imagen_mime'] ?? 'image/jpeg')));
if ($imagenBase64Raw === '') {
    json_response(422, [
        'ok' => false,
        'error' => 'image_required',
        'message' => 'Por favor toma o selecciona una foto del problema antes de enviar.',
    ]);
}

if (str_starts_with($imagenBase64Raw, 'data:')) {
    if (preg_match('/^data:(image\/[a-z0-9.+-]+);base64,(.+)$/i', $imagenBase64Raw, $m)) {
        $imagenMime = strtolower($m[1]);
        $imagenBase64Raw = $m[2];
    }
}

if (!in_array($imagenMime, GEMINI_ALLOWED_IMAGE_MIMES, true)) {
    json_response(422, [
        'ok' => false,
        'error' => 'invalid_image_mime',
        'message' => 'Formato de imagen no compatible. Usa fotografía JPG, PNG o WEBP.',
    ]);
}

$imagenBytes = base64_decode($imagenBase64Raw, true);
if ($imagenBytes === false || strlen($imagenBytes) === 0) {
    json_response(422, [
        'ok' => false,
        'error' => 'invalid_image_data',
        'message' => 'La fotografía enviada está dañada. Toma otra foto e intenta de nuevo.',
    ]);
}

$maxImageBytes = (int) ($CONFIG['MAX_IMAGE_BYTES'] ?? 1572864);
if (strlen($imagenBytes) > $maxImageBytes) {
    json_response(422, [
        'ok' => false,
        'error' => 'image_too_large',
        'message' => 'La fotografía es demasiado pesada (máximo 1.5 MB). Intenta tomarla de nuevo.',
    ]);
}

$textoVoz = trim((string) ($body['texto_voz'] ?? ''));
$descripcionManual = trim((string) ($body['descripcion_manual'] ?? ''));
if (mb_strlen($textoVoz, 'UTF-8') > 1000 || mb_strlen($descripcionManual, 'UTF-8') > 1000) {
    json_response(422, [
        'ok' => false,
        'error' => 'text_too_long',
        'message' => 'La descripción es demasiado larga (máximo 1000 caracteres).',
    ]);
}

$audioBase64Raw = trim((string) ($body['audio_base64'] ?? ''));
$audioMime = strtolower(trim((string) ($body['audio_mime'] ?? 'audio/ogg')));
if ($textoVoz !== '') {
    $audioBase64Raw = '';
} elseif ($audioBase64Raw !== '') {
    if (str_starts_with($audioBase64Raw, 'data:')) {
        if (preg_match('/^data:(audio\/[a-z0-9.+-]+)(?:;[^;,]+)*;base64,(.+)$/i', $audioBase64Raw, $m)) {
            $audioMime = strtolower($m[1]);
            $audioBase64Raw = $m[2];
        }
    }
    if (!in_array($audioMime, GEMINI_ALLOWED_AUDIO_MIMES, true)) {
        json_response(422, [
            'ok' => false,
            'error' => 'invalid_audio_mime',
            'message' => 'Formato de audio no compatible. Intenta hablar de nuevo o escribir el problema.',
        ]);
    }
    $audioBytes = base64_decode($audioBase64Raw, true);
    $maxAudioBytes = (int) ($CONFIG['MAX_AUDIO_BYTES'] ?? 2097152);
    if ($audioBytes === false || strlen($audioBytes) === 0 || strlen($audioBytes) > $maxAudioBytes) {
        json_response(422, [
            'ok' => false,
            'error' => 'audio_too_large',
            'message' => 'El audio supera el tamaño permitido (máximo 2 MB) o no se pudo leer.',
        ]);
    }
}

$latRaw = $body['lat'] ?? null;
$lngRaw = $body['lng'] ?? null;
if (!is_numeric($latRaw) || !is_numeric($lngRaw)) {
    json_response(422, [
        'ok' => false,
        'error' => 'invalid_coordinates',
        'message' => 'Las coordenadas de ubicación no son válidas.',
    ]);
}

$lat = (float) $latRaw;
$lng = (float) $lngRaw;
if ($lat < -90.0 || $lat > 90.0 || $lng < -180.0 || $lng > 180.0) {
    json_response(422, [
        'ok' => false,
        'error' => 'invalid_coordinates',
        'message' => 'Las coordenadas están fuera de rango geográfico.',
    ]);
}

$fueraDeZona = !($lat >= 28.80 && $lat <= 29.35 && $lng >= -111.30 && $lng <= -110.65);
$colonia = mb_substr(trim((string) ($body['colonia'] ?? 'Hermosillo')), 0, 120, 'UTF-8');
$ubicacionTexto = mb_substr(
    trim((string) ($body['ubicacion_texto'] ?? sprintf('Hermosillo, Sonora (%.3f, %.3f)', $lat, $lng))),
    0,
    255,
    'UTF-8'
);
$guardar = !isset($body['guardar']) || (bool) $body['guardar'];

$systemInstruction = implode("\n", [
    'Eres un asistente ciudadano especializado en accesibilidad urbana e infraestructura municipal en Hermosillo, Sonora, México.',
    'Tu tarea es ayudar a adultos mayores y personas con debilidad visual o movilidad reducida a clasificar fallas en la vía pública y redactar un reporte formal.',
    'REGLAS ESTRICTAS DE PRIVACIDAD Y VERACIDAD:',
    '1. NUNCA describas rostros, características físicas de personas, ropa ni placas de vehículos que aparezcan en la fotografía.',
    '2. NUNCA inventes números telefónicos, correos electrónicos, direcciones de oficinas ni canales oficiales de atención.',
    '3. Asigna únicamente una de estas dependencias probables de Hermosillo: "Obras Públicas / CIDUE", "Alumbrado Público", "Agua de Hermosillo", "Servicios Públicos" o "Protección Civil".',
    '4. Redacta "mensaje_usuario" en español claro, cálido y de lectura fácil, explicando que el reporte se generó para que la persona lo comparta o entregue (no digas que ya se envió automáticamente al municipio).',
]);

$parts = [
    [
        'inlineData' => [
            'mimeType' => $imagenMime,
            'data' => $imagenBase64Raw,
        ],
    ],
];

if ($audioBase64Raw !== '') {
    $parts[] = [
        'inlineData' => [
            'mimeType' => $audioMime,
            'data' => $audioBase64Raw,
        ],
    ];
}

$promptLines = [
    'Analiza la fotografía adjunta' . ($audioBase64Raw !== '' ? ' y el audio ciudadano' : '') . '.',
    'Ubicación aproximada: ' . $ubicacionTexto . ' (lat ' . round($lat, 3) . ', lng ' . round($lng, 3) . ').',
];
if ($textoVoz !== '') {
    $promptLines[] = 'Transcripción de voz del ciudadano: "' . $textoVoz . '"';
}
if ($descripcionManual !== '') {
    $promptLines[] = 'Nota escrita adicional: "' . $descripcionManual . '"';
}
if ($fueraDeZona) {
    $promptLines[] = 'Nota: las coordenadas están fuera del área urbana principal de Hermosillo; indícalo con respeto en el campo ubicación.';
}

$parts[] = ['text' => implode("\n", $promptLines)];

$responseSchema = [
    'type' => 'OBJECT',
    'properties' => [
        'es_problema_urbano' => ['type' => 'BOOLEAN'],
        'tipo_obstaculo' => ['type' => 'STRING'],
        'riesgo' => ['type' => 'STRING', 'enum' => ['Alto', 'Medio', 'Bajo']],
        'motivo_riesgo' => ['type' => 'STRING'],
        'dependencia' => [
            'type' => 'STRING',
            'enum' => [
                'Obras Públicas / CIDUE',
                'Alumbrado Público',
                'Agua de Hermosillo',
                'Servicios Públicos',
                'Protección Civil',
            ],
        ],
        'confianza_dependencia' => ['type' => 'STRING', 'enum' => ['Alta', 'Media', 'Baja']],
        'reporte_formal' => [
            'type' => 'OBJECT',
            'properties' => [
                'asunto' => ['type' => 'STRING'],
                'descripcion' => ['type' => 'STRING'],
                'ubicacion' => ['type' => 'STRING'],
                'evidencia' => ['type' => 'STRING'],
                'afectacion_accesibilidad' => ['type' => 'STRING'],
                'prioridad_sugerida' => ['type' => 'STRING', 'enum' => ['Urgente', 'Media', 'Programada']],
            ],
            'required' => [
                'asunto',
                'descripcion',
                'ubicacion',
                'evidencia',
                'afectacion_accesibilidad',
                'prioridad_sugerida',
            ],
        ],
        'resumen_corto' => ['type' => 'STRING'],
        'mensaje_usuario' => ['type' => 'STRING'],
    ],
    'required' => [
        'es_problema_urbano',
        'tipo_obstaculo',
        'riesgo',
        'motivo_riesgo',
        'dependencia',
        'confianza_dependencia',
        'reporte_formal',
        'resumen_corto',
        'mensaje_usuario',
    ],
];

try {
    $rawAnalisis = gemini_generar($CONFIG, $systemInstruction, $parts, $responseSchema, 0.3);
} catch (RuntimeException $e) {
    $code = $e->getMessage();
    error_log('[ReporteCiudadanoHMO] Gemini analizar error: ' . $code);
    if ($code === 'gemini_blocked') {
        json_response(422, [
            'ok' => false,
            'error' => 'gemini_blocked',
            'message' => 'No pudimos analizar esa imagen. Asegúrate de fotografiar únicamente la calle, banqueta o falla urbana.',
        ]);
    }
    json_response(502, [
        'ok' => false,
        'error' => $code,
        'message' => 'El servicio de análisis tardó demasiado o no está disponible ahora. Intenta de nuevo en unos segundos.',
    ]);
}

$dependenciasValidas = [
    'Obras Públicas / CIDUE',
    'Alumbrado Público',
    'Agua de Hermosillo',
    'Servicios Públicos',
    'Protección Civil',
];
$riesgosValidos = ['Alto', 'Medio', 'Bajo'];
$confianzasValidas = ['Alta', 'Media', 'Baja'];
$prioridadesValidas = ['Urgente', 'Media', 'Programada'];

$esProblemaUrbano = array_key_exists('es_problema_urbano', $rawAnalisis)
    ? (bool) $rawAnalisis['es_problema_urbano']
    : true;
$tipoObstaculo = trim((string) ($rawAnalisis['tipo_obstaculo'] ?? 'Falla en vía pública'));
if ($tipoObstaculo === '') {
    $tipoObstaculo = 'Falla en vía pública';
}
$riesgo = in_array($rawAnalisis['riesgo'] ?? '', $riesgosValidos, true)
    ? (string) $rawAnalisis['riesgo']
    : 'Medio';
$motivoRiesgo = trim((string) ($rawAnalisis['motivo_riesgo'] ?? 'Puede dificultar el paso seguro de peatones.'));
$dependencia = in_array($rawAnalisis['dependencia'] ?? '', $dependenciasValidas, true)
    ? (string) $rawAnalisis['dependencia']
    : 'Obras Públicas / CIDUE';
$confianza = in_array($rawAnalisis['confianza_dependencia'] ?? '', $confianzasValidas, true)
    ? (string) $rawAnalisis['confianza_dependencia']
    : 'Media';

$rfRaw = is_array($rawAnalisis['reporte_formal'] ?? null) ? $rawAnalisis['reporte_formal'] : [];
$reporteFormal = [
    'asunto' => trim((string) ($rfRaw['asunto'] ?? 'Solicitud de atención a falla urbana en Hermosillo')),
    'descripcion' => trim((string) ($rfRaw['descripcion'] ?? $motivoRiesgo)),
    'ubicacion' => trim((string) ($rfRaw['ubicacion'] ?? $ubicacionTexto)),
    'evidencia' => trim((string) ($rfRaw['evidencia'] ?? 'Fotografía capturada en sitio por ciudadano.')),
    'afectacion_accesibilidad' => trim((string) ($rfRaw['afectacion_accesibilidad'] ?? 'Afecta el tránsito seguro de adultos mayores y personas con movilidad reducida.')),
    'prioridad_sugerida' => in_array($rfRaw['prioridad_sugerida'] ?? '', $prioridadesValidas, true)
        ? (string) $rfRaw['prioridad_sugerida']
        : ($riesgo === 'Alto' ? 'Urgente' : 'Media'),
];

$resumenCorto = trim((string) ($rawAnalisis['resumen_corto'] ?? $tipoObstaculo));
$mensajeUsuario = trim((string) ($rawAnalisis['mensaje_usuario'] ?? "Listo, preparamos tu reporte sobre {$tipoObstaculo} dirigido a {$dependencia} para que puedas compartirlo."));

$analisis = [
    'es_problema_urbano' => $esProblemaUrbano,
    'tipo_obstaculo' => $tipoObstaculo,
    'riesgo' => $riesgo,
    'motivo_riesgo' => $motivoRiesgo,
    'dependencia' => $dependencia,
    'confianza_dependencia' => $confianza,
    'reporte_formal' => $reporteFormal,
    'resumen_corto' => $resumenCorto,
    'mensaje_usuario' => $mensajeUsuario,
];

$latRedondeada = round($lat, 3);
$lngRedondeada = round($lng, 3);
$folio = null;

if ($esProblemaUrbano && $guardar) {
    $fechaHoy = (new DateTimeImmutable('now', new DateTimeZone('America/Hermosillo')))->format('Ymd');
    $folio = sprintf('RC-%s-%04d', $fechaHoy, random_int(1000, 9999));

    $stmt = $pdo->prepare(
        'INSERT INTO reportes (
            folio, tipo_obstaculo, riesgo, motivo_riesgo, dependencia, confianza_dependencia,
            resumen_corto, reporte_formal_json, mensaje_usuario, colonia, ubicacion_texto,
            lat, lng, fuera_de_zona, es_demo, activo
        ) VALUES (
            :folio, :tipo_obstaculo, :riesgo, :motivo_riesgo, :dependencia, :confianza_dependencia,
            :resumen_corto, :reporte_formal_json, :mensaje_usuario, :colonia, :ubicacion_texto,
            :lat, :lng, :fuera_de_zona, 0, 1
        )'
    );

    $stmt->execute([
        ':folio' => $folio,
        ':tipo_obstaculo' => mb_substr($tipoObstaculo, 0, 160, 'UTF-8'),
        ':riesgo' => $riesgo,
        ':motivo_riesgo' => mb_substr($motivoRiesgo, 0, 500, 'UTF-8'),
        ':dependencia' => $dependencia,
        ':confianza_dependencia' => $confianza,
        ':resumen_corto' => mb_substr($resumenCorto, 0, 220, 'UTF-8'),
        ':reporte_formal_json' => json_encode($reporteFormal, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        ':mensaje_usuario' => $mensajeUsuario,
        ':colonia' => $colonia !== '' ? $colonia : 'Hermosillo',
        ':ubicacion_texto' => $ubicacionTexto,
        ':lat' => $latRedondeada,
        ':lng' => $lngRedondeada,
        ':fuera_de_zona' => $fueraDeZona ? 1 : 0,
    ]);
}

json_response(200, [
    'ok' => true,
    'folio' => $folio,
    'fuera_de_zona' => $fueraDeZona,
    'lat' => $latRedondeada,
    'lng' => $lngRedondeada,
    'analisis' => $analisis,
]);
