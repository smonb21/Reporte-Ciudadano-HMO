<?php
declare(strict_types=1);

require_once __DIR__ . '/../lib/bootstrap.php';

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'GET') {
    json_response(405, [
        'ok' => false,
        'error' => 'method_not_allowed',
        'message' => 'Método no permitido.',
    ]);
}

require_app_token($CONFIG);
$pdo = get_pdo($CONFIG);
enforce_rate_limit($pdo, $CONFIG, 'reportes');

$lat = isset($_GET['lat']) && is_numeric($_GET['lat']) ? (float) $_GET['lat'] : 29.0729;
$lng = isset($_GET['lng']) && is_numeric($_GET['lng']) ? (float) $_GET['lng'] : -110.9559;
if ($lat < -90.0 || $lat > 90.0 || $lng < -180.0 || $lng > 180.0) {
    $lat = 29.0729;
    $lng = -110.9559;
}

$radioKm = isset($_GET['radio_km']) && is_numeric($_GET['radio_km']) ? (float) $_GET['radio_km'] : 2.0;
$radioKm = max(0.1, min(10.0, $radioKm));

$limite = isset($_GET['limite']) && is_numeric($_GET['limite']) ? (int) $_GET['limite'] : 30;
$limite = max(1, min(50, $limite));

$sql = "
    SELECT
        folio,
        tipo_obstaculo,
        riesgo,
        motivo_riesgo,
        dependencia,
        resumen_corto,
        colonia,
        ubicacion_texto,
        lat,
        lng,
        es_demo,
        creado_en,
        ROUND(
            6371 * ACOS(
                LEAST(1.0, GREATEST(-1.0,
                    COS(RADIANS(:lat1)) * COS(RADIANS(lat)) * COS(RADIANS(lng) - RADIANS(:lng1))
                    + SIN(RADIANS(:lat2)) * SIN(RADIANS(lat))
                ))
            ),
            2
        ) AS distancia_km
    FROM reportes
    WHERE activo = 1
    HAVING distancia_km <= :radio_km
    ORDER BY FIELD(riesgo, 'Alto', 'Medio', 'Bajo') ASC, creado_en DESC
    LIMIT :limite
";

$stmt = $pdo->prepare($sql);
$stmt->bindValue(':lat1', $lat);
$stmt->bindValue(':lng1', $lng);
$stmt->bindValue(':lat2', $lat);
$stmt->bindValue(':radio_km', $radioKm);
$stmt->bindValue(':limite', $limite, PDO::PARAM_INT);
$stmt->execute();

$rows = $stmt->fetchAll();

json_response(200, [
    'ok' => true,
    'centro' => [
        'lat' => round($lat, 3),
        'lng' => round($lng, 3),
        'radio_km' => $radioKm,
    ],
    'total' => count($rows),
    'reportes' => $rows,
]);
