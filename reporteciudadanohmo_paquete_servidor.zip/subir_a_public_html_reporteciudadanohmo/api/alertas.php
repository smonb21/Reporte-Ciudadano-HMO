<?php
declare(strict_types=1);

require_once __DIR__ . '/../lib/bootstrap.php';
require_once __DIR__ . '/../lib/gemini.php';

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'GET') {
    json_response(405, [
        'ok' => false,
        'error' => 'method_not_allowed',
        'message' => 'Método no permitido.',
    ]);
}

require_app_token($CONFIG);
$pdo = get_pdo($CONFIG);
enforce_rate_limit($pdo, $CONFIG, 'alertas');

$lat = isset($_GET['lat']) && is_numeric($_GET['lat']) ? (float) $_GET['lat'] : 29.0729;
$lng = isset($_GET['lng']) && is_numeric($_GET['lng']) ? (float) $_GET['lng'] : -110.9559;
if ($lat < -90.0 || $lat > 90.0 || $lng < -180.0 || $lng > 180.0) {
    $lat = 29.0729;
    $lng = -110.9559;
}

$zonaClave = sprintf('%.2f,%.2f', round($lat, 2), round($lng, 2));
$cacheMin = max(1, (int) ($CONFIG['ALERTAS_CACHE_MIN'] ?? 10));

$cacheStmt = $pdo->prepare(
    'SELECT respuesta_json FROM alertas_cache WHERE zona_clave = :zona_clave AND actualizado_en >= DATE_SUB(NOW(), INTERVAL :cache_min MINUTE) LIMIT 1'
);
$cacheStmt->bindValue(':zona_clave', $zonaClave, PDO::PARAM_STR);
$cacheStmt->bindValue(':cache_min', $cacheMin, PDO::PARAM_INT);
$cacheStmt->execute();
$cached = $cacheStmt->fetch();

if (is_array($cached) && !empty($cached['respuesta_json'])) {
    $decodedCache = json_decode((string) $cached['respuesta_json'], true);
    if (is_array($decodedCache)) {
        json_response(200, [
            'ok' => true,
            'zona_clave' => $zonaClave,
            'cache' => true,
            'resumen_general' => $decodedCache['resumen_general'] ?? '',
            'alertas' => $decodedCache['alertas'] ?? [],
        ]);
    }
}

$sqlReportes = "
    SELECT
        tipo_obstaculo,
        riesgo,
        resumen_corto,
        colonia,
        ubicacion_texto,
        ROUND(
            6371 * ACOS(
                LEAST(1.0, GREATEST(-1.0,
                    COS(RADIANS(:lat1)) * COS(RADIANS(lat)) * COS(RADIANS(lng) - RADIANS(:lng1))
                    + SIN(RADIANS(:lat2)) * SIN(RADIANS(lat))
                ))
            ),
            2
        ) AS distancia_km
    FROM reportes
    WHERE activo = 1
    HAVING distancia_km <= 3.0
    ORDER BY FIELD(riesgo, 'Alto', 'Medio', 'Bajo') ASC, creado_en DESC
    LIMIT 20
";

$repStmt = $pdo->prepare($sqlReportes);
$repStmt->execute([
    ':lat1' => $lat,
    ':lng1' => $lng,
    ':lat2' => $lat,
]);
$cercanos = $repStmt->fetchAll();

if (count($cercanos) === 0) {
    json_response(200, [
        'ok' => true,
        'zona_clave' => $zonaClave,
        'cache' => false,
        'resumen_general' => 'No hay alertas urbanas activas registradas cerca de tu ubicación en este momento. Puedes caminar con tranquilidad y reportar cualquier obstáculo que veas.',
        'alertas' => [],
    ]);
}

$systemInstruction = implode("\n", [
    'Eres un asistente comunitario de movilidad segura en Hermosillo, Sonora.',
    'Resume reportes urbanos activos en lenguaje muy sencillo, claro y directo para adultos mayores y personas con debilidad visual o movilidad reducida.',
    'No inventes teléfonos, direcciones ni canales oficiales.',
    'Genera máximo 4 alertas prácticas.',
]);

$schema = [
    'type' => 'OBJECT',
    'properties' => [
        'resumen_general' => ['type' => 'STRING'],
        'alertas' => [
            'type' => 'ARRAY',
            'items' => [
                'type' => 'OBJECT',
                'properties' => [
                    'titulo' => ['type' => 'STRING'],
                    'recomendacion' => ['type' => 'STRING'],
                    'nivel' => ['type' => 'STRING', 'enum' => ['Alto', 'Medio', 'Bajo']],
                    'referencia' => ['type' => 'STRING'],
                ],
                'required' => ['titulo', 'recomendacion', 'nivel', 'referencia'],
            ],
        ],
    ],
    'required' => ['resumen_general', 'alertas'],
];

$parts = [
    [
        'text' => "Resume estos reportes cercanos en máximo 4 alertas prácticas de movilidad:\n"
            . json_encode($cercanos, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
    ],
];

try {
    $resultado = gemini_generar($CONFIG, $systemInstruction, $parts, $schema, 0.4);
    $resumenGeneral = trim((string) ($resultado['resumen_general'] ?? 'Revisa las alertas activas en tu zona antes de caminar.'));
    $alertas = is_array($resultado['alertas'] ?? null) ? array_slice($resultado['alertas'], 0, 4) : [];
} catch (RuntimeException $e) {
    error_log('[ReporteCiudadanoHMO] Gemini alertas error: ' . $e->getMessage());
    $resumenGeneral = 'Hay ' . count($cercanos) . ' reportes activos cerca de tu zona. Camina con precaución en los puntos señalados.';
    $alertas = [];
    foreach (array_slice($cercanos, 0, 4) as $r) {
        $alertas[] = [
            'titulo' => (string) ($r['resumen_corto'] ?? $r['tipo_obstaculo']),
            'recomendacion' => 'Evita pasar justo sobre el obstáculo y busca una banqueta o cruce alternativo.',
            'nivel' => in_array($r['riesgo'] ?? '', ['Alto', 'Medio', 'Bajo'], true) ? (string) $r['riesgo'] : 'Medio',
            'referencia' => (string) ($r['ubicacion_texto'] ?: $r['colonia']),
        ];
    }
}

$payloadCache = [
    'resumen_general' => $resumenGeneral,
    'alertas' => $alertas,
];

$upsert = $pdo->prepare(
    'INSERT INTO alertas_cache (zona_clave, respuesta_json, actualizado_en)
     VALUES (:zona_clave, :respuesta_json, NOW())
     ON DUPLICATE KEY UPDATE respuesta_json = VALUES(respuesta_json), actualizado_en = NOW()'
);
$upsert->execute([
    ':zona_clave' => $zonaClave,
    ':respuesta_json' => json_encode($payloadCache, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
]);

json_response(200, [
    'ok' => true,
    'zona_clave' => $zonaClave,
    'cache' => false,
    'resumen_general' => $resumenGeneral,
    'alertas' => $alertas,
]);
