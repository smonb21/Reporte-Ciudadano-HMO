# Reporte Ciudadano HMO · Paquete de Despliegue (HostGator cPanel)

Aplicación web móvil accesible para Hermosillo, Sonora. Clasifica fallas urbanas con asistencia de IA y prepara el reporte formal para compartirlo o entregarlo (la aplicación **no** realiza envíos automáticos al municipio).

## Contenido del ZIP
1. `config_fuera_de_public_html/reporte_config.example.php`: Renombrar a `reporte_config.php` y subir **fuera** de `public_html` en `/home2/beceacbf/config/reporte_config.php`.
2. `subir_a_public_html_reporteciudadanohmo/`: Contenido listo para subir vía FTP/cPanel dentro de `/home2/beceacbf/public_html/reporteciudadanohmo/` (incluye `api/`, `lib/`, `sql/`, `.htaccess` y `dist/` precompilado con `base: '/reporteciudadanohmo/'`).
3. `frontend_fuente_para_recompilar/`: Código fuente React + Vite para compilar nuevamente cuando agregues tu `VITE_APP_TOKEN` en `.env.local`.

## Pasos rápidos en la sesión de servidor
1. **Base de datos MySQL 8 (phpMyAdmin)**:
   - Selecciona `beceacbf_reporteciudadanohmo` (usuario `beceacbf_reporteciudadanoadmin`).
   - Importa `sql/schema.sql` y luego `sql/seed_demo_hermosillo.sql`.
2. **Configuración secreta fuera de `public_html`**:
   - Crea `/home2/beceacbf/config/` y sube `reporte_config.example.php` renombrado a `reporte_config.php` (permisos `600`).
   - El capitán captura directamente en el servidor las constantes `define(...)`:
     - `define('GEMINI_API_KEY', '...');`: API key nueva de la cuenta del equipo en Google AI Studio (`Get API key`).
     - `define('GEMINI_MODEL', '...');`: nombre exacto del modelo usado en pruebas (en AI Studio → `Get code`, por ejemplo `gemini-2.5-flash` o el modelo activo en esa cuenta).
     - `define('DB_PASS', '...');`: contraseña de MySQL del usuario `beceacbf_reporteciudadanoadmin`.
     - `define('APP_TOKEN', '...');`: cadena aleatoria de **40 o más caracteres** (la misma que ya pusieron en Flutter, o genera una de 48 caracteres con `openssl rand -hex 24`).
3. **Compilar frontend con el `APP_TOKEN` elegido**:
   ```bash
   cd frontend_fuente_para_recompilar
   echo 'VITE_APP_TOKEN="EL_MISMO_APP_TOKEN_DEL_SERVIDOR"' > .env.local
   npm install
   npm run build
   ```
   - Verifica que `dist/` **no** contenga ninguna clave de Google (prefijo `A-I-z-a`) ni librerías cliente de Gemini en el navegador.
   - Sube el contenido de `dist/` junto con `api/`, `lib/`, `sql/` y `.htaccess` a `/home2/beceacbf/public_html/reporteciudadanohmo/`.

## Pruebas `curl` reales
```bash
curl -i "https://clubdecienciafronteriza.com/reporteciudadanohmo/api/ping.php"
curl -i -X POST "https://clubdecienciafronteriza.com/reporteciudadanohmo/api/analizar.php" -H "Content-Type: application/json" -d '{"imagen_base64":"AAAA","lat":29.07,"lng":-110.96}'
curl -i -H "X-App-Token: TU_APP_TOKEN" "https://clubdecienciafronteriza.com/reporteciudadanohmo/api/reportes.php?lat=29.07&lng=-110.96"
curl -i -H "X-App-Token: TU_APP_TOKEN" "https://clubdecienciafronteriza.com/reporteciudadanohmo/api/alertas.php?lat=29.07&lng=-110.96"
curl -i "https://clubdecienciafronteriza.com/reporteciudadanohmo/sql/"
```

## Checklist de seguridad y privacidad
- `GEMINI_API_KEY` solo existe en `/home2/beceacbf/config/reporte_config.php` (nunca en GitHub ni en `dist/`).
- No se guardan fotografías ni audios en MySQL ni en archivos del servidor.
- Las coordenadas en base de datos se redondean a 3 decimales y las IPs del rate limit se guardan como hash SHA-256.
- Si una clave se compartió o filtró, revócala en Google AI Studio y genera una nueva antes de la sesión.

## Declaración de uso de IA
Frontend prototipado con Google AI Studio (Build) y backend generado con asistencia de Google Gemini a partir de un prompt proporcionado por el asesor (redactado con apoyo de Claude, de Anthropic); revisados y ajustados por el equipo; alojado en un hosting personal del asesor.
